# App Id
3074457362992623916

# Install dependencies
`npm i`

# Prepare scripts and deploy to firebase server 
`npm run dist`

Note: Firebase cli needs to be installed and authenticated once before using firebase deploy command

# Installable Link:

`Leanlanes`

https://miro.com/oauth/authorize/?response_type=code&client_id=3074457362992623916&redirect_uri=%2Fconfirm-app-install%2F
