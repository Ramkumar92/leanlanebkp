let allowedHrefProtocols = ["http", "https", "ftp", "ftps"];

export const sanitizeUrl = (e, t = allowedHrefProtocols) => {
    if (!e)
        return false;
    if (e.startsWith("/"))
        return e;
    var n = e.indexOf(":");
    if (n <= 0)
        return false;
    for (var i = (e = (e = (e = (e = e.replace(/(')/g, "%27"))
        .replace(/(")/g, "%22"))
        .replace(/{/g, "%7B"))
        .replace(/}/g, "%7D"))
        .substring(0, n)
        .toLowerCase(), s = 0; s < t.length; s++)
        if (i === t[s])
            return e;
    return "http" === i ? "https" + e.substring(n) : false;
}