import { analyticsEvents } from "../services/firebase/consts";
import { createWidgets, showNotification } from "../services/miro/manipulate";
import { isLeanLaneWidget, isLeanStoryMirror, isLeanStoryWidget } from "../services/miro/validations";

const downloadTextFile = (text, name) => {
    const a = document.createElement('a');
    const type = name.split(".").pop();
    a.href = URL.createObjectURL(new Blob([text], { type: `text/${type === "txt" ? "plain" : type}` }));
    a.download = name;
    a.click();
}

const selectFile = (contentType, multiple = false) => {
    return new Promise(resolve => {
        let input = document.createElement('input');
        input.type = 'file';
        input.multiple = multiple;
        input.accept = contentType;

        input.onchange = _ => {
            let files = Array.from(input.files);
            if (multiple)
                resolve(files);
            else
                resolve(files[0]);
        };

        input.click();
    });
}

const segregateWidgets = (widgets, appId) => {
    let regularBoardWidgets = widgets.filter(({ metadata }) => !metadata[appId]?.mirror);
    regularBoardWidgets = regularBoardWidgets.filter(({type, url}) => !(type === "IMAGE" && !Boolean(url.length)));
    const mirroredBoardWidgets = widgets.filter(({ metadata }) => metadata[appId]?.mirror);
    return [regularBoardWidgets, mirroredBoardWidgets];
}


export const backupData = async (firebase) => {

    showNotification('Preparing backup file, Will be downloaded shortly');
    let boardWidgets = await window.miro.board.widgets.get();

    if (!boardWidgets.length) return;

    let docs = [];
    try {
        docs = await firebase.getDocuments(boardWidgets.map(({ id }) => id));

        let firebaseWidgets = [];
        docs.forEach(doc => {
            if (doc.exists) firebaseWidgets.push({ id: doc.id, ...(doc.data() || {}) });
        });

        downloadTextFile(JSON.stringify({ boardWidgets, firebaseWidgets }, null, 3), 'backup.json');
    } catch (error) {
        window.firebase.analytics().logEvent(analyticsEvents.log_error, error);
    }

}

export const restoreData = async (firebase, appId) => {

    const file = await selectFile("text/json");
    const fileContent = await file.text();
    const idMap = {};

    try {
        const { boardWidgets, firebaseWidgets } = JSON.parse(fileContent);
        let [regularBoardWidgets, mirroredBoardWidgets] = segregateWidgets(boardWidgets, appId);

        const newRegularBoardWidgets = await createWidgets(regularBoardWidgets);

        newRegularBoardWidgets.forEach(({ id }, index) => idMap[regularBoardWidgets[index].id] = id);

        mirroredBoardWidgets = mirroredBoardWidgets.map(widgets => {
            let metadata = {};
            metadata[appId] = {
                ...widgets.metadata[appId],
                parentId: idMap[widgets.metadata[appId].parentId]
            }
            return { ...widgets, metadata };
        });

        const newMirroredBoardWidgets = await createWidgets(mirroredBoardWidgets);

        newMirroredBoardWidgets.forEach(({ id }, index) => idMap[mirroredBoardWidgets[index].id] = id);

        const newFirebaseWidgets = firebaseWidgets.map(widget => {
            const stories = (widget.stories || []).map(story => {
                let newStory = {
                    ...story,
                    id: idMap[story.id],
                }
                if (story.parentId) {
                    newStory = { ...newStory, parentId: idMap[story.parentId] };
                }
                return newStory;
            });
            return {
                ...widget,
                id: idMap[widget.id],
                stories
            }
        });

        firebase.createDocuments(newFirebaseWidgets);

    } catch (error) {
        window.firebase.analytics().logEvent(analyticsEvents.log_error, error);
    }

}