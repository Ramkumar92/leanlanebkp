
export const UPDATE_APP_ID = "UPDATE_APP_ID";

export const updateAppId = (data) => {
    return { type: UPDATE_APP_ID, payload: data }
}
