
export const UPDATE_BOARD_INFO = "UPDATE_BOARD_INFO";

export const updateBoardInfo = (data) => {
    return { type: UPDATE_BOARD_INFO, payload: data }
}
