
export const initialState = {
    appId: null,
    selection: [],
    boardInfo: { id: null },
    deferSelection: false,
    deferredSelection: [],
    clipboardData: {},
    widgetTitles: {},
    privacyPolicyUrl: 'https://docs.google.com/document/d/1LHb4au6uPryduCxDI2L7kLHD3jhuBcjhUWvPlIB87dM/'
    // appId: "3074457358572683177",
    // boardInfo: { id: "o9J_lWDpbfE=" },
    // selection: [{
    //     "id": "3074457359145528606",
    //     "type": "SHAPE",
    //     "plainText": "New LeanLane",
    //     "metadata": {
    //         "3074457358572683177": {
    //             "leanLanes": true
    //         }
    //     },
    //     "capabilities": {
    //         "editable": true
    //     },

    // }]
}