import { AppProvider } from './store';
import './App.css';
import 'react-virtualized/styles.css';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from './pages/home';
import Sidebar from './pages/sidebar';
import Modal from './pages/modal';
import MirrorStory from './pages/modal/mirrorStory';
import Login from './pages/login';
import 'mirotone/dist/styles.css';
import TextPreview from './components/textPreview';

window.firebase.initializeApp({
  apiKey: 'AIzaSyA8DZI6NOcU3tZi6r-4QwHFE2vap8thJOI',
  authDomain: window.location.hostname,
  projectId: 'leanlanes-3e41f',
  storageBucket: 'gs://leanlanes-3e41f.appspot.com',
  appId: '1:807410716452:web:e8f57d5bfa64276348adb1'
});
window.firebase.analytics();
window.gtag('config', 'G-X24JM4LYCS', { cookie_flags: 'secure;samesite=none' });

const App = () => (
  <AppProvider>
    <Router>
      <Switch>
        <Route exact path="/">
          <Home />
        </Route>
        <Route path="/sidebar">
          <Sidebar />
        </Route>
        <Route path="/modal">
          <Modal />
        </Route>
        <Route path="/pastemodal">
          <MirrorStory />
        </Route>
        <Route path="/login">
          <Login />
        </Route>
        <Route path="/test">
          <TextPreview />
        </Route>
      </Switch>
    </Router>
  </AppProvider>
);

export default App;
