import { useContext, useEffect, useState } from 'react';
import FeedbackButton from '../../components/iconButtons/feedback';
import Lanes from '../../components/iconButtons/lanes';
import Print from '../../components/iconButtons/print';
import Stories from '../../components/iconButtons/stories';
import { analyticsEvents } from '../../services/firebase/consts';
import { storage } from '../../services/firebase/firebase';
import { createLeanLanesWidget, createLeanStoryWidget } from '../../services/miro/manipulate';
import { AppContext } from '../../store';
import { backupData, restoreData } from '../../utils/backupRestore';
import './style.css';

export const NoSelection = ({ loggedOut }) => {

    const [{ selection, appId, boardInfo: { id: boardId } }] = useContext(AppContext);
    const [boardHasWidgets, setBoardHasWidgets] = useState(false);
    const [firebase] = useState(new storage(boardId));

    useEffect(() => {
        window.miro.board.widgets.get()
            .then(res => {
                if (res.length) setBoardHasWidgets(true);
            });
    }, []);

    const logOut = () => {
        window.firebase.auth().signOut().then(function () {
            window.location.reload();
        }, function (error) {
            // An error happened.
        });
    }

    const openAuthWindow = () => {
        var newWindow = window.open(window.location.origin + '/login', '_blank', 'height=600,width=450');
        if (window.focus) {
            newWindow.focus();
        }
    }

    const handleBackupRestore = async () => {
        const widgets = await window.miro.board.widgets.get();
        if (selection.length || widgets.length) {
            backupData(firebase, appId);
        } else {
            await restoreData(firebase, appId);
            setBoardHasWidgets(true);
        }
    }

    return (
        <div className='no-selection-padding-right'>
            <div className='miro-h3 font-500 column-margin row-margin'>
                Create your first LeanNote
            </div>
            <div className='column-margin row-margin--medium'>
                <span className='miro-h5 font-500 vertical-align-text'>Use this icon to create LeanNote</span>
                <span className='icon-float-right'>
                    <Stories onClick={() => {
                        createLeanStoryWidget(appId);
                        window.firebase.analytics().logEvent(analyticsEvents.create_leanstory);
                    }} />
                </span>
            </div>
            <div className='miro-h6 font-500 column-margin row-margin--medium'>
                LeanNotes have superpowers, you can add a description, links and connect them to Cards on a Miro board.
            </div>

            <div className='miro-h3 font-500 column-margin row-margin'>
                Build your first LeanFlow
            </div>
            <div className='column-margin row-margin--medium'>
                <span className='miro-h5 font-500 vertical-align-text'>Use this icon to create LeanFlow</span>
                <span className='icon-float-right'>
                    <Lanes onClick={() => {
                        createLeanLanesWidget(appId);
                        window.firebase.analytics().logEvent(analyticsEvents.create_leangroup);
                    }} />
                </span>
            </div>
            <div className='miro-h6 font-500 column-margin row-margin--medium'>
                LeanFlows allow you to build a sequence of LeanNotes that present particular flows through your LeanNotes.
            </div>

            <div className='miro-h3 font-500 column-margin row-margin'>
                Print your LeanFlows
            </div>
            <div className='column-margin row-margin--medium'>
                <span className='miro-h5 font-500 vertical-align-text'>Use this icon to print a LeanFlow</span>
                <span className='icon-float-right'><Print /></span>
            </div>
            <div className='miro-h6 font-500 column-margin row-margin--medium'>
                Magic happens when you click this icon, your LeanFlow is printed to the Board providing a clear overview.
            </div>
            <FeedbackButton
                onClick={() => window.miro.board.ui.openModal('modal', { width: 480, height: 440 })}
            />
            {!loggedOut &&
                <button
                    onClick={handleBackupRestore}
                    className="miro-btn miro-btn--primary miro-btn--small backup-button">
                    {selection.length || boardHasWidgets ? 'Download Backup' : 'Upload Backup'}
                </button>
            }
            <button
                onClick={loggedOut ? () => openAuthWindow() : () => logOut()}
                className="miro-btn miro-btn--primary miro-btn--small logout-button">
                {loggedOut ? 'Login to access Leanlanes' : 'Logout'}
            </button>
        </div>
    )
}