import { useContext, useEffect, useState } from "react";
import AddComment from "../../components/addComment";
import Comments from "../../components/comments";
import ContextMenu from "../../components/contextMenu";
import MoreHorizontal from "../../components/iconButtons/moreHorizontal";
import Input from "../../components/input/input";
import LinkContents from "../../components/linkContents";
import PageNav from "../../components/pageNav";
import Skeleton from "../../components/skeleton";
import StoryContents from "../../components/storyContents";
import Switch from "../../components/switch";
import TextPreview from "../../components/textPreview";
import { analyticsEvents } from "../../services/firebase/consts";
import { storage } from "../../services/firebase/firebase";
import { createLeanStoryWidget, focusStory, focusWidgetById, getWidgetById, updateWidgetText } from "../../services/miro/manipulate";
import { AppContext } from "../../store";
import { setWidgetTitles } from '../../store/actions/selection';
import './style.css';

const LeanNoteReadonly = ({ stories }) => {

    const [{ appId, boardInfo: { id: boardId },
        deferredSelection, widgetTitles }, dispatch] = useContext(AppContext);
    const [widgetData, setWidgetData] = useState({ isLoading: true });
    const [activeTab, setActiveTab] = useState('');
    const [firebase] = useState(new storage(boardId));
    const [showContext, setShowContext] = useState(false);
    const [storyIndex, setStoryIndex] = useState(0);
    const storyId = stories[storyIndex].parentId || stories[storyIndex].id;
    const currentId = stories[storyIndex].id;

    useEffect(() => {
        setWidgetData({ isLoading: true });
        setActiveTab('Comments');
        focusStory(currentId);
        firebase.readData(storyId)
            .then(data => setWidgetData(data))
            .catch(err => window.firebase.analytics().logEvent(analyticsEvents.log_error, err));

    }, [storyId, currentId, firebase]);

    const handleTitleChange = (title) => {
        updateWidgetText(storyId, title);
        firebase.mergeData(storyId, { title });
        let newWidgetTitles = { ...widgetTitles };
        newWidgetTitles[storyId] = {
            ...widgetTitles[storyId],
            plainText: title
        };
        dispatch(setWidgetTitles(newWidgetTitles));
    }

    const handleDescChange = (desc) => {
        setWidgetData({ ...widgetData, desc });
        firebase.mergeData(storyId, { desc });
    }

    const addComment = ({ dateAdded, user, comment }) => {
        firebase.mergeData(storyId,
            { comments: [...(widgetData.comments || []), { dateAdded, user, comment }] });
        setWidgetData({
            ...widgetData,
            comments: [...(widgetData.comments || []), { dateAdded, user, comment }]
        });
    }

    const updateComments = (comments) => {
        firebase.mergeData(storyId, { comments });
        setWidgetData({ ...widgetData, comments });
    }

    const handleMirror = async () => {
        const [widget] = await getWidgetById(storyId);
        createLeanStoryWidget(appId, storyId, true, true, widget.height, widget.width);
        window.firebase.analytics().logEvent(analyticsEvents.create_mirror);
    }

    const handleTitleClick = () => {
        focusWidgetById(storyId);
    }

    return (
        <>
            <PageNav
                total={stories.length}
                currentIndex={storyIndex}
                onChange={v => setStoryIndex(v)} />
            <div className='leanstory__title flex relative'>
                <Input className='miro-h3 font-500 miro-input--primary width-100'
                    multiLine
                    value={stories[storyIndex].overRideText || widgetTitles[storyId]?.plainText}
                    onClick={handleTitleClick}
                    onChange={v => handleTitleChange(v)}
                />
                <MoreHorizontal
                    className='leanstory__title-more-icon'
                    onClick={() => setShowContext(true)}
                />
                {showContext &&
                    <ContextMenu
                        className='leanstory__context_menu'
                        menuOptions={['Mirror']}
                        onClose={(item) => {
                            setShowContext(false);
                            if (item === 'Mirror') handleMirror();
                        }}
                    />
                }
            </div>
            <div className='leanstory__desc-container'>
                <Skeleton isLoading={widgetData.isLoading}>
                    <TextPreview
                        mini
                        widgetId={storyId}
                        text={widgetData?.desc}
                        onChange={handleDescChange} />
                </Skeleton>
            </div>
            <Switch
                options={["User Stories", "Links", 'Comments']}
                active={activeTab}
                setActive={v => setActiveTab(v)}
            />
            <div className='row-margin--medium'>
                {activeTab === "User Stories" &&
                    <Skeleton isLoading={widgetData.isLoading}>
                        <StoryContents
                            readOnly
                            deferredSelection={deferredSelection}
                            stories={widgetData.stories} />
                    </Skeleton>
                }
                {activeTab === "Links" &&
                    <Skeleton isLoading={widgetData.isLoading}>
                        <LinkContents
                            links={widgetData.links}
                            readOnly
                        />
                    </Skeleton>
                }
                {activeTab === "Comments" &&
                    <>
                        <Skeleton isLoading={widgetData.isLoading}>
                            <Comments
                                comments={widgetData.comments}
                                updateComments={updateComments}
                            />
                        </Skeleton>
                        <AddComment onChange={addComment} />
                    </>
                }
            </div>
        </>
    );
}

export default LeanNoteReadonly;