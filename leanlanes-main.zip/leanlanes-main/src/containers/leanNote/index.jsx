import { useContext, useEffect, useState } from "react";
import AddLink from "../../components/addLink";
import AddStories from "../../components/addStories";
import Input from "../../components/input/input";
import LinkContents from "../../components/linkContents";
import Skeleton from "../../components/skeleton";
import StoryContents from "../../components/storyContents";
import Switch from "../../components/switch";
import TextPreview from "../../components/textPreview";
import { storage } from "../../services/firebase/firebase";
import { widgetTypes } from "../../services/miro/consts";
import { deferSelection as defer, deleteClipboardData, setWidgetTitles } from '../../store/actions/selection';
import { updateWidgetText, getCurrentSelection, focusWidgetById, createLeanStoryWidget, getWidgetById, getWidgets, selectWidgets } from "../../services/miro/manipulate";
import { AppContext } from "../../store";
import MoreHorizontal from "../../components/iconButtons/moreHorizontal";
import ContextMenu from "../../components/contextMenu";
import './style.css';
import AddComment from "../../components/addComment";
import Comments from "../../components/comments";
import { analyticsEvents } from "../../services/firebase/consts";

const LeanNote = () => {

    const [{ selection: [selectedWidget], appId, boardInfo: { id: boardId },
        clipboardData, deferredSelection, widgetTitles }, dispatch] = useContext(AppContext);
    const [deferSelection, setDeferSelection] = useState(false);
    const [widgetData, setWidgetData] = useState({ isLoading: true });
    const [activeTab, setActiveTab] = useState('');
    const [editLink, setEditLink] = useState({});
    const [firebase] = useState(new storage(boardId));
    const [showContext, setShowContext] = useState(false);

    useEffect(() => {

        setWidgetData({ isLoading: true });
        setDeferSelection(false);
        setActiveTab('User Stories');

        firebase.readData(selectedWidget.id)
            .then(data => setWidgetData(data))
            .catch(err => window.firebase.analytics().logEvent(analyticsEvents.log_error, err));

    }, [selectedWidget, firebase]);

    useEffect(() => {
        const handleSync = async () => {
            let cardWidgetsSelected = await getCurrentSelection();
            cardWidgetsSelected = cardWidgetsSelected.filter(wid => wid.type === widgetTypes.CARD);
            if (cardWidgetsSelected && cardWidgetsSelected.length) {
                cardWidgetsSelected = cardWidgetsSelected.map(widget => ({
                    id: widget.id,
                    title: widget.title,
                    description: widget.description
                }));

                setWidgetData(widgetData => {
                    let newStories = cardWidgetsSelected.filter(card =>
                        !(widgetData.stories || []).find(story => story.id === card.id));
                    let stories = Array.from(widgetData.stories || []);
                    // if (cardWidgetsSelected.length > 1) {
                    //     stories = Array.from(widgetData.stories || []);
                    // }
                    // else {
                    //     stories = (widgetData.stories || []).filter(story => !cardWidgetsSelected
                    //         .find(card => card.id === story.id));
                    // }
                    stories = [...stories, ...newStories];
                    firebase.mergeData(selectedWidget.id, { stories });
                    if (newStories.length) {
                        window.firebase.analytics().logEvent(analyticsEvents.add_userstory);
                    }
                    return ({ ...widgetData, stories });
                });
            }
        }

        if (deferSelection && deferredSelection.length) {
            handleSync();
        }

    }, [deferSelection, deferredSelection, firebase, widgetTitles, selectedWidget.id]);

    const handleTitleChange = (title) => {
        updateWidgetText(selectedWidget.id, title);
        firebase.mergeData(selectedWidget.id, { title });
        let newWidgetTitles = { ...widgetTitles };
        newWidgetTitles[selectedWidget.id] = {
            ...widgetTitles[selectedWidget.id],
            plainText: title
        };
        dispatch(setWidgetTitles(newWidgetTitles));
    }

    const handleDescChange = (desc) => {
        setWidgetData({ ...widgetData, desc });
        firebase.mergeData(selectedWidget.id, { desc });
    }

    const addLink = ({ dateAdded, linkTitle, link }) => {
        if (editLink.title || editLink.link) {
            const links = Array.from(widgetData.links || []);
            links[editLink.index] = { ...links[editLink.index], linkTitle, link };
            firebase.mergeData(selectedWidget.id, { links });
            setWidgetData({ ...widgetData, links });
            setEditLink({});
        } else {
            firebase.mergeData(selectedWidget.id,
                { links: [...(widgetData.links || []), { dateAdded, linkTitle, link }] });
            setWidgetData({
                ...widgetData,
                links: [...(widgetData.links || []), { dateAdded, linkTitle, link }]
            });
        }
    }

    const addComment = ({ dateAdded, user, comment }) => {
        firebase.mergeData(selectedWidget.id,
            { comments: [...(widgetData.comments || []), { dateAdded, user, comment }] });
        setWidgetData({
            ...widgetData,
            comments: [...(widgetData.comments || []), { dateAdded, user, comment }]
        });
    }

    const updateLinks = (links) => {
        firebase.mergeData(selectedWidget.id, { links });
        setWidgetData({ ...widgetData, links });
    }

    const updateComments = (comments) => {
        firebase.mergeData(selectedWidget.id, { comments });
        setWidgetData({ ...widgetData, comments });
    }

    const handleStoryChange = (newStories) => {
        firebase.mergeData(selectedWidget.id, { stories: newStories });
        setWidgetData({ ...widgetData, stories: newStories });
    }

    const handleMirror = async () => {
        const [widget] = await getWidgetById(selectedWidget.id);
        createLeanStoryWidget(appId, selectedWidget.id, true, true, widget.height, widget.width);
        window.firebase.analytics().logEvent(analyticsEvents.create_mirror);
    }

    const checkPasteEnable = () => {
        return clipboardData.link &&
            clipboardData.createId !== selectedWidget.id &&
            !(widgetData.links || []).find(({ link, linkTitle }) =>
                (link === clipboardData.link.link && linkTitle === clipboardData.link.linkTitle))
    }

    const handleTitleClick = () => {
        focusWidgetById(selectedWidget.id);
    }

    const handleSelectAll = async () => {
        const widgetId = selectedWidget.metadata[appId].parentId || selectedWidget.id;
        let allWidgets = await getWidgets();
        const widgetsToSelect = allWidgets.filter((widget) => {
            if (widget.id === widgetId) return true;
            if (widget.metadata[appId]?.parentId === widgetId) return true;
            return false;
        });

        selectWidgets(widgetsToSelect);
    }

    return (
        <div className='column-margin'>
            <div className='leanstory__title flex relative'>
                <Input className='miro-h3 font-500 miro-input--primary width-100'
                    multiLine
                    value={widgetTitles[selectedWidget.id]?.plainText}
                    onClick={handleTitleClick}
                    onChange={v => handleTitleChange(v)}
                />
                <span>
                    <MoreHorizontal
                        className='leanstory__title-more-icon'
                        onClick={() => setShowContext(true)}
                    />
                </span>
                {showContext &&
                    <ContextMenu
                        className='leanstory__context_menu'
                        menuOptions={['Mirror', 'Select All']}
                        onClose={(item) => {
                            setShowContext(false);
                            if (item === 'Mirror') handleMirror();
                            if (item === 'Select All') handleSelectAll();
                        }}
                    />
                }
            </div>
            <div className='leanstory__desc-container'>
                <Skeleton isLoading={widgetData.isLoading}>
                    <TextPreview
                        widgetId={selectedWidget.id}
                        text={widgetData?.desc}
                        onChange={handleDescChange} />
                </Skeleton>
            </div>
            <Switch
                options={["User Stories", "Links", 'Comments']}
                active={activeTab}
                setActive={v => setActiveTab(v)}
            />
            <div className='row-margin--medium'>
                {activeTab === "User Stories" &&
                    <>
                        <Skeleton isLoading={widgetData.isLoading}>
                            <StoryContents
                                deferredSelection={deferredSelection}
                                stories={widgetData.stories}
                                onChange={handleStoryChange} />
                        </Skeleton>
                        <AddStories
                            deferSelection={deferSelection}
                            setDeferSelection={(v) => {
                                if (v) dispatch(defer([]));
                                setDeferSelection(v);
                            }} />
                    </>
                }
                {activeTab === "Links" &&
                    <>
                        <Skeleton isLoading={widgetData.isLoading}>
                            <LinkContents
                                links={widgetData.links}
                                updateLinks={updateLinks}
                                setEditLink={v => setEditLink(v)}
                            />
                            {checkPasteEnable() &&
                                <>
                                    <button
                                        onClick={() => {
                                            addLink(clipboardData.link);
                                            dispatch(deleteClipboardData());
                                        }}
                                        className='miro-btn miro-btn--small miro-btn--primary float-right'
                                    >
                                        paste
                                    </button>
                                    <button
                                        onClick={() => dispatch(deleteClipboardData())}
                                        className='miro-btn miro-btn--small miro-btn--primary float-right cancel-btn'
                                    >
                                        cancel
                                    </button>
                                </>
                            }
                        </Skeleton>
                        <AddLink
                            defaultTitle={editLink.title}
                            defaultLink={editLink.link}
                            onChange={addLink} />
                    </>
                }
                {activeTab === "Comments" &&
                    <>
                        <Skeleton isLoading={widgetData.isLoading}>
                            <Comments
                                comments={widgetData.comments}
                                updateComments={updateComments}
                            />
                        </Skeleton>
                        <AddComment onChange={addComment} />
                    </>
                }
            </div>
        </div>
    );
}

export default LeanNote;