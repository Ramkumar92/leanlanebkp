import { useContext, useState } from 'react';
import { createLeanLanesWidget, createLeanStoryWidget, getBoardXY, showNotification } from '../../services/miro/manipulate';
import { AppContext } from '../../store';
import Divider from '../../components/divider';
import Lanes from '../../components/iconButtons/lanes';
import Print from '../../components/iconButtons/print';
import Stories from '../../components/iconButtons/stories';
import './style.css';
import { isLeanLaneWidget } from '../../services/miro/validations';
import { storage } from '../../services/firebase/firebase';
import { handlePrint } from './processPrint';
import { analyticsEvents } from '../../services/firebase/consts';
import { selectionChanged } from '../../store/actions/selection';

const Header = () => {

    const [{ selection, appId, boardInfo: { id: boardId } }, dispatch] = useContext(AppContext);
    const [firebase] = useState(new storage(boardId));

    const delegatePrint = async () => {
        showNotification('Click anywhere in the board to print');
        let { x, y } = await getBoardXY();
        handlePrint(firebase, selection?.[0]?.id, appId, x, y);
    }

    const handleNavigation = () => {
        dispatch(selectionChanged([]));
    }

    return (
        <>
            <div className='app-header column-margin'>
                <span className='header-text' onClick={handleNavigation}>LeanLanes</span>
                <div className='vertical-divider' />
                <Stories onClick={() => {
                    createLeanStoryWidget(appId);
                    window.firebase.analytics().logEvent(analyticsEvents.create_leanstory);
                }} />
                <Lanes onClick={() => {
                    createLeanLanesWidget(appId);
                    window.firebase.analytics().logEvent(analyticsEvents.create_leangroup);
                }} />
                <Print
                    disabled={!isLeanLaneWidget(selection, appId)}
                    onClick={() => delegatePrint()}
                />
            </div>
            <div className='column-margin app-header__divider'>
                <Divider />
            </div>
        </>
    );
}

export default Header;