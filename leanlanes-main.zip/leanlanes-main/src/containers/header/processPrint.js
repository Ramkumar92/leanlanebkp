import { analyticsEvents } from "../../services/firebase/consts";
import { widgetTypes } from "../../services/miro/consts";
import { createWidgets, deleteWidget, getWidgets } from "../../services/miro/manipulate";

const storyWidth = 160;
const storyHeight = 90;
const storySpace = 40;
const titleHeight = 68;
const rowSpace = 50;
const smallRowSpace = 20;
const deleteIconWidth = 24;
const warning_text = "<p>Delete icon removes this content. </p><p>Make updates in the LeanLanes app interface.</p>";
const delete_icon = window.location.origin + '/images/delete_icon.svg';

export const handlePrint = async (firebase, widgetId, appId, x, y) => {

    const widgetData = await firebase.readData(widgetId);
    const printId = Date.now();
    const metadata = {};
    metadata[appId] = { printId, widgetId };

    let maxStories = widgetData?.stories?.length || 0;

    const storyData = await getStoryWidgets(firebase, getWidgetIds(widgetData));

    const titleWidth = (maxStories * (storyWidth + storySpace)) - storySpace;

    let currX = x;
    let currY = y;

    const titleMetadata = {};
    titleMetadata[appId] = { printId, widgetId, type: 'title', id: widgetId };
    createWidgets(getShapeTemplate({
        width: titleWidth,
        height: titleHeight,
        x: currX + (titleWidth / 2) - (storyWidth / 2),
        y: currY,
        metadata: titleMetadata,
        text: widgetData.title
    }, { fontSize: 24 }));

    createWidgets(getDescTemplate({
        width: 350,
        x: currX + titleWidth - 200,
        y: currY - 50,
        scale: 0.7,
        metadata,
        text: warning_text
    }, { textAlign: "r", textColor: "#f24726" }));

    createWidgets(getImageTemplate({
        width: deleteIconWidth,
        x: currX + titleWidth - 90,
        y: currY - 20,
        metadata,
        scale: 0.6,
        url: delete_icon
    }));

    currY += rowSpace;
    let storyRowX = currX;

    createWidgets(getTextTemplate({
        width: titleWidth,
        x: currX + titleWidth / 2 - storyWidth / 2,
        y: currY,
        metadata,
        text: '<p><strong>' + widgetData.title + '</strong></p>'
    }));

    currY += smallRowSpace;

    let maxStoryDescLength = 0;
    let storyIds = [];
    (widgetData.stories || []).forEach(story => storyIds.push(story.id));
    storyIds.forEach(storyId => {
        if (storyData[storyId]?.desc?.length > maxStoryDescLength) {
            maxStoryDescLength = storyData[storyId].desc?.length;
        }
    });

    (widgetData.stories || []).forEach(story => {
        let storyRowY = currY + rowSpace;

        const storyMetadata = {};
        storyMetadata[appId] = { printId, widgetId, type: 'story', id: story.id };
        createWidgets(getShapeTemplate({
            width: storyWidth,
            height: storyHeight,
            x: storyRowX,
            y: storyRowY,
            metadata: storyMetadata,
            text: story.overRideText || story.text
        }));

        if (storyData[story.parentId || story.id]?.desc) {
            storyRowY += rowSpace;

            const paddedDesc = storyData[story.parentId || story.id].desc;
            createWidgets(getDescTemplate({
                width: storyWidth,
                x: storyRowX,
                y: storyRowY + getRowHeight(paddedDesc.length) / 2,
                metadata,
                text: paddedDesc
            }));

            storyRowY += getRowHeight(maxStoryDescLength);
        }

        if (storyData[story.parentId || story.id]?.stories) {
            storyRowY += rowSpace;
            storyData[story.parentId || story.id].stories.forEach(story => {
                createWidgets(getCardTemplate({
                    width: storyWidth,
                    scale: 0.6,
                    x: storyRowX,
                    y: storyRowY,
                    metadata,
                    title: story.title,
                    description: story.description
                }))
                storyRowY += rowSpace + smallRowSpace;
            });
        }

        storyRowX += (storyWidth + storySpace);
    });

}

// const getSpaces = (stringLen, totalLength) => {
//     return " ".repeat(Math.min(totalLength - stringLen) * 2);
// }

const getRowHeight = (length) => {
    return Math.ceil(length / 24) * 20;
}

export const handleDelete = async (widget, appId) => {

    const printId = widget[0].metadata[appId].printId;

    let allWidgets = await getWidgets();

    for (let i = 0; i < allWidgets.length; i++) {
        if (allWidgets[i].metadata[appId]?.printId === printId) {
            await deleteWidget({ id: allWidgets[i].id });
        }
    }
}

const getShapeTemplate = (props, style) => {

    return {
        type: widgetTypes.SHAPE,
        style: {
            backgroundColor: "#fff9b1",
            backgroundOpacity: 1,
            bold: 0,
            borderColor: "transparent",
            borderOpacity: 1,
            borderStyle: 2,
            borderWidth: 2,
            fontFamily: 10,
            fontSize: 14,
            highlighting: 0,
            italic: 0,
            shapeType: 3,
            strike: 0,
            textAlign: "c",
            textAlignVertical: "m",
            textColor: "#1a1a1a",
            underline: 0,
            ...(style || {})
        },
        capabilities: {
            editable: false
        },
        clientVisible: true,
        rotation: 0,
        ...props
    };
}

const getTextTemplate = (props) => {
    return {
        "type": "TEXT",
        "style": {
            "backgroundColor": "transparent",
            "backgroundOpacity": 1,
            "textAlign": "l",
            "textColor": "#1a1a1a",
            "fontFamily": 10,
            "padding": 0,
            "bold": 1,
            "underline": 0,
            "italic": 0,
            "strike": 0,
            "borderColor": "transparent",
            "borderOpacity": 1,
            "borderWidth": 2,
            "borderStyle": 2,
            "highlighting": ""
        },
        "capabilities": {
            "editable": false
        },
        "clientVisible": true,
        ...props
    }
}

const getDescTemplate = (props, style) => {

    return {
        "type": "TEXT",
        "style": {
            "backgroundColor": "transparent",
            "backgroundOpacity": 1,
            "textAlign": "l",
            "textColor": "#1a1a1a",
            "fontFamily": 10,
            "padding": 0,
            "bold": 0,
            "underline": 0,
            "italic": 0,
            "strike": 0,
            "borderColor": "transparent",
            "borderOpacity": 1,
            "borderWidth": 2,
            "borderStyle": 2,
            "highlighting": "",
            ...(style || {})
        },
        "capabilities": {
            "editable": false
        },
        "clientVisible": true,
        "rotation": 0,
        ...props
    }
}

const getImageTemplate = (props) => {
    return {
        "type": "IMAGE",
        "capabilities": {
            "editable": false
        },
        "clientVisible": true,
        "rotation": 0,
        "title": "",
        ...props
    }
}

const getCardTemplate = (props) => {
    return {
        "type": "CARD",
        "style": {
            "backgroundColor": "#2d9bf0"
        },
        "capabilities": {
            "editable": false
        },
        "clientVisible": true,
        "rotation": 0,
        "tags": [],
        "card": {},
        ...props
    }
}

const getStoryWidgets = async (firebase, widgetIds) => {
    let leanWidgets = {};
    await firebase
        .getDocuments(widgetIds)
        .then((docs) =>
            docs.forEach(doc => {
                if (doc.exists) leanWidgets[doc.id] = { ...(doc.data() || {}) };
            }))
        .catch(err => window.firebase.analytics().logEvent(analyticsEvents.log_error, err));

    return leanWidgets;
}

const getWidgetIds = (widgetData) => {
    let widgetIds = []

    widgetData.stories.forEach(story => {
        widgetIds.push(story.parentId || story.id);
    });

    return widgetIds;
}