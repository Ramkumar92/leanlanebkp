import { useContext, useEffect, useState } from "react";
import AddLeanStories from "../../components/addLeanStories";
import Play from "../../components/iconButtons/play";
import Stop from "../../components/iconButtons/stop";
import Input from "../../components/input/input";
import Skeleton from "../../components/skeleton";
import StoryList from "../../components/storyList";
import TextPreview from "../../components/textPreview";
import { analyticsEvents } from "../../services/firebase/consts";
import { storage } from "../../services/firebase/firebase";
import { widgetTypes } from "../../services/miro/consts";
import { focusWidgetById, getCurrentSelection, getWidgets, updateWidgetText } from "../../services/miro/manipulate";
import { isLeanStoryWidget } from "../../services/miro/validations";
import { AppContext } from "../../store";
import { setDeferSelection } from "../../store/actions/selection";
import LeanNoteReadonly from "../leanNote/leanNoteReadonly";
import './style.css';

const defaultUiState = { editable: false, playStories: null };

const checkStoryExists = (story, selectedStories) => {
    return Boolean(selectedStories.find(select => select.id === story.id));
}

const getStoryText = (id, widgets) => {
    let match = widgets.find(widget => widget.id === id);
    return (match?.plainText || "(Deleted)");
}

const LeanLane = () => {

    const [{ appId, selection: [selectedWidget],
        boardInfo: { id: boardId },
        deferSelection,
        deferredSelection }, dispatch] = useContext(AppContext);
    const [widgetData, setWidgetData] = useState({ isLoading: true });
    const [firebase] = useState(new storage(boardId));
    const [uiState, setUiState] = useState(defaultUiState);
    const [presentMode, setPresentMode] = useState(false);

    useEffect(() => {

        setUiState(defaultUiState);
        setPresentMode(false);
        setWidgetData({ isLoading: true });
        firebase.readData(selectedWidget.id)
            .then(async (data) => {
                let widgets = await getWidgets({ type: widgetTypes.SHAPE });
                const stories = data.stories?.map(story => {
                    return { ...story, text: getStoryText(story.id, widgets) }
                });
                setWidgetData({ ...data, stories, title: getStoryText(selectedWidget.id, widgets) });
            })
            .catch(err => window.firebase.analytics().logEvent(analyticsEvents.log_error, err));

    }, [selectedWidget, firebase]);

    useEffect(() => {
        const handleSync = async () => {

            let selectedWidgets = await getCurrentSelection();
            selectedWidgets = selectedWidgets.filter(wid => isLeanStoryWidget(wid, appId));
            if (selectedWidgets && selectedWidgets.length) {
                selectedWidgets = selectedWidgets.map(widget => ({
                    id: widget.id,
                    parentId: widget.metadata[appId]?.parentId || "",
                    text: widget.plainText
                }));

                setWidgetData(widgetData => {
                    let newStories = selectedWidgets
                        .filter(story => !checkStoryExists(story, (widgetData.stories || [])));
                    let stories = Array.from(widgetData.stories || []);
                    stories = [...stories, ...newStories];

                    firebase.mergeData(selectedWidget.id, { stories });
                    return ({ ...widgetData, stories });
                });
            }
        }

        if (deferSelection && deferredSelection.length && uiState.playStories === null) {
            handleSync();
        }

    }, [deferSelection, deferredSelection, firebase, dispatch,
        selectedWidget.id, appId, uiState]);

    const handleLaneTitleChange = (title) => {
        updateWidgetText(selectedWidget.id, title);
        setWidgetData({ ...widgetData, title });
        firebase.mergeData(selectedWidget.id, { title });
    }

    const handleLaneDescChange = (desc) => {
        setWidgetData({ ...widgetData, desc });
        firebase.mergeData(selectedWidget.id, { desc });
    }

    const handleStoryChange = (stories) => {
        setWidgetData({ ...widgetData, stories });
        firebase.mergeData(selectedWidget.id, { stories });
    }

    return (
        <div className='column-margin'>

            {/* Header section */}
            <div className='row-margin--medium flex'>
                <Skeleton
                    isLoading={widgetData.isLoading}
                    className='flex-grow'>
                    <div className='flex'>
                        <Input className='miro-h3 font-500 miro-input--primary width-100'
                            multiLine
                            value={widgetData?.title}
                            onChange={v => handleLaneTitleChange(v)}
                            onClick={() => focusWidgetById(selectedWidget.id)}
                        />
                        <span>
                            {presentMode ?
                                <Stop onClick={() => setPresentMode(false)} />
                                :
                                <Play
                                    disabled={deferSelection || !widgetData?.stories?.length}
                                    onClick={() => setPresentMode(true)} />
                            }
                        </span>
                    </div>
                </Skeleton>
            </div>

            {/* Description section */}
            <div className='row-margin--medium'>
                <Skeleton isLoading={widgetData.isLoading}>
                    <TextPreview
                        widgetId={selectedWidget.id}
                        text={widgetData?.desc}
                        onChange={handleLaneDescChange} />
                </Skeleton>
            </div>

            {presentMode ?
                <LeanNoteReadonly stories={widgetData?.stories} />
                :
                <>
                    <div className='row-margin--medium'>
                        <Skeleton isLoading={widgetData.isLoading}>
                            <StoryList
                                editable={uiState.editable}
                                stories={widgetData?.stories}
                                onChange={handleStoryChange} />
                        </Skeleton>
                    </div>

                    <AddLeanStories
                        deferSelection={deferSelection}
                        setDeferSelection={v => dispatch(setDeferSelection(v))}
                    />
                </>
            }

        </div>
    )
}

export default LeanLane;