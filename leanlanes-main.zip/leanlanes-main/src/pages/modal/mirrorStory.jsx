import qs from 'qs';
import { updateWidgetMetadata, updateWidgetData, getWidgetById } from '../../services/miro/manipulate';
import Close from '../../components/iconButtons/close';
import './mirror-story.css';

const MirrorStory = () => {

    const { widgetIds, appId } = qs.parse(window.location.search.slice(1));
    const widgets = widgetIds.split(',');

    const handleMirror = async () => {
        for (let i = 0; i < widgets.length; i++) {
            const widget = await getWidgetById(widgets[i]);
            const metadata = {};
            metadata[appId] = { ...(widget[0]?.metadata[appId] || {}), mirror: true };
            await updateWidgetData({
                ...widget[0],
                capabilities: { editable: false },
                metadata
            });
        }
        window.miro.board.ui.closeModal();
    }

    const handleNew = async () => {
        for (let i = 0; i < widgets.length; i++) {
            const metadata = {};
            metadata[appId] = { leanStory: true, uniqueStoryId: Date.now() };
            await updateWidgetMetadata(widgets[i], metadata);
        }
        window.miro.board.ui.closeModal();
    }

    return (
        <div className='row-margin column-margin mirror-modal-container'>
            <div className='flex'>
                <h4 className='miro-h4 font-500 text-align-center flex-grow'>
                    Paste Modal: Mirror or New
                </h4>
            </div>
            <Close className='mirror-story-close'
                onClick={() => window.miro.board.ui.closeModal()} />
            <div style={{ height: 24 }} />
            <button
                onClick={handleMirror}
                className='row-margin column-margin miro-btn miro-btn--secondary width-100
                mirror-story-button'>
                <span className='miro-h3 font-500'>MIRROR</span>
            </button>
            <button
                onClick={handleNew}
                className='row-margin column-margin miro-btn miro-btn--secondary width-100
                mirror-story-button'>
                <span className='miro-h3 font-500'>NEW</span>
            </button>
        </div>
    );
}
export default MirrorStory;