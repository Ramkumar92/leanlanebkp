import { useContext, useEffect } from "react";
import { isLeanLaneWidget, isLeanStoryWidget } from "../../services/miro/validations";
import { AppContext } from "../../store";

const Home = () => {

    const [, dispatch] = useContext(AppContext);
    const leanLanesIcon = '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><rect fill="none" height="24" width="24"/><path d="M19,3H5C3.9,3,3,3.9,3,5v14c0,1.1,0.9,2,2,2h14c1.1,0,2-0.9,2-2V5C21,3.9,20.1,3,19,3z M19,5v3H5V5H19z M19,10v4H5v-4H19z M5,19v-3h14v3H5z"/></svg>';


    useEffect(() => {
        const { miro } = window;
        miro.onReady(async () => {
            const toolbar = {
                title: 'LeanLanes',
                librarySvgIcon: leanLanesIcon,
                toolbarSvgIcon: leanLanesIcon,
                onClick: async () => {
                    const isAuthorized = await miro.isAuthorized();
                    if (!isAuthorized) {
                        await miro.requestAuthorization();
                    }

                    miro.board.ui.openLeftSidebar('sidebar');
                }
            };

            miro.initialize({ extensionPoints: { toolbar } });

            let appId = await miro.getClientId();
            miro.addListener(miro.enums.event.SELECTION_UPDATED, ({ data }) => {
                if (isLeanLaneWidget(data, appId) || isLeanStoryWidget(data, appId)) {
                    miro.board.ui.openLeftSidebar('sidebar');
                }
            });
        });
    }, [dispatch]);

    return <div />;
}
export default Home;