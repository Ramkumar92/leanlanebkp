import { useContext, useEffect, useState } from 'react';
import Header from '../../containers/header';
import { NoSelection } from '../../containers/noSelection';
import { AppContext } from '../../store';
import { updateAppId } from '../../store/actions/app';
import {
    deferSelection, handleWidgetsDelete, selectionChanged
} from '../../store/actions/selection';
import {
    isLeanLaneWidget, isLeanStoryWidget, isPrintWidget,
    isPrintStoryWidget, isPrintTitleWidget, isLeanStoryMirror
} from '../../services/miro/validations';
import LeanLane from '../../containers/leanLane';
import LeanNote from '../../containers/leanNote';
import { updateBoardInfo } from '../../store/actions/board';
import { dataSync } from '../../services/syncService/dataSync';
import { handleDelete } from '../../containers/header/processPrint';
import { getWidgetById, selectWidget } from '../../services/miro/manipulate';
import { withRouter } from 'react-router-dom';

const loginState = {
    INDETERMINATE: 0,
    NOT_LOGGED_IN: 1,
    LOGGED_IN: 2
}

const Sidebar = ({ history }) => {

    const [{ selection, appId, boardInfo: { id: boardId } }, dispatch] = useContext(AppContext);
    const [loggedIn, setLoggedIn] = useState(loginState.INDETERMINATE);

    useEffect(() => {

        window.firebase.auth().onAuthStateChanged(function (user) {
            if (user) {
                window.firebaseUser = user;
                if (!loggedIn) setLoggedIn(loginState.LOGGED_IN);
            } else {
                setLoggedIn(loginState.NOT_LOGGED_IN);
            }
        });

        const { miro } = window;
        miro.onReady(async () => {
            const miroAppId = await miro.getClientId();
            const boardInfo = await miro.board.info.get();
            const sync = new dataSync(dispatch, boardInfo.id, miroAppId);

            miro.addListener(miro.enums.event.SELECTION_UPDATED, ({ data }) => {
                if (isLeanStoryMirror(data, miroAppId)) {
                    getWidgetById(data[0].metadata[miroAppId].parentId, miroAppId)
                        .then((parentWidget) => dispatch(selectionChanged(parentWidget)));
                } else if (isLeanStoryWidget(data, miroAppId)
                    || isLeanLaneWidget(data, miroAppId)) {
                    dispatch(selectionChanged(data));
                } else if (data.length) {
                    dispatch(deferSelection(data));
                }
                if (isPrintWidget(data, miroAppId)) {
                    handleDelete(data, miroAppId);
                }
                else if (isPrintStoryWidget(data, miroAppId) || isPrintTitleWidget(data, miroAppId)) {
                    selectWidget(data[0].metadata[miroAppId].id)
                }
                sync.syncWidgets();
            });

            miro.addListener(miro.enums.event.WIDGETS_DELETED, data => {
                dispatch(handleWidgetsDelete(data));
            });

            sync.syncWidgets();

            dispatch(updateBoardInfo(boardInfo));
            dispatch(updateAppId(miroAppId));
            dispatch(selectionChanged(await miro.board.selection.get()));
        });

    }, [history, dispatch, loggedIn]);

    return (
        <>
            {boardId && <Header />}
            {loggedIn === loginState.LOGGED_IN &&
                <>
                    {isLeanLaneWidget(selection, appId) && <LeanLane />}
                    {isLeanStoryWidget(selection, appId) && <LeanNote />}
                    {!isLeanLaneWidget(selection, appId) &&
                        !isLeanStoryWidget(selection, appId) && <NoSelection />}
                </>
            }
            {loggedIn === loginState.NOT_LOGGED_IN &&
                <NoSelection loggedOut />
            }
        </>
    );
}
export default withRouter(Sidebar);