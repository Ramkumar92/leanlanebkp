
export const widgetTypes = {
    SHAPE: 'SHAPE',
    CARD: 'CARD',
    IMAGE: 'IMAGE'
}