export const analyticsEvents = {
    add_comment: 'add_comment',
    add_link: 'add_link',
    add_userstory: 'add_userstory',
    create_leangroup: 'create_leangroup',
    create_leanstory: 'create_leanstory',
    create_mirror: 'create_mirror',
    log_error: 'log_error'
}