
export class storage {

    constructor(boardId) {
        this.db = window.firebase.firestore();
        this.collection = this.db.collection(boardId);
    }

    uploadFile = (base64, bucketFileName) => {
        return new Promise((resolve, reject) => {
            var ref = window.firebase.storage().ref('/user_uploads/' + bucketFileName);
            const base64Data = base64.split(',')[1];
            ref.putString(base64Data, 'base64').then((snapshot) => {
                snapshot.ref.getDownloadURL().then(async (downloadURL) => {
                    resolve(downloadURL);
                })
            });
        });
    }

    writeData = (widgetId, data) => {
        return this.collection.doc(widgetId)
            .set({
                ...data,
                modifiedTimestamp: window.firebase.firestore.FieldValue.serverTimestamp()
            });
    }

    createDocuments = async (documents) => {
        const batch = this.db.batch();
        documents.forEach((doc) => {
            var docRef = this.collection.doc(doc.id);
            batch.set(docRef, {
                ...doc,
                modifiedTimestamp: window.firebase.firestore.FieldValue.serverTimestamp()
            });
        });
        await batch.commit();
    }

    mergeData = (widgetId, data) => {
        return this.collection.doc(widgetId)
            .set({
                ...data,
                modifiedTimestamp: window.firebase.firestore.FieldValue.serverTimestamp()
            }
                , { merge: true });
    }

    queryDocuments = (field, condition, searchValue) => {
        return new Promise((resolve, reject) => {
            this.collection.where(field, condition, searchValue)
                .get()
                .then(results => resolve(results.docs))
                .catch(err => reject(err));
        });
    }

    getDocuments = (documentIds) => {
        return new Promise((res) => {
            // don't run if there aren't any ids for the collection
            if (!documentIds || !documentIds.length) return res([]);

            let batches = [];

            while (documentIds.length) {
                // firestore limits batches to 10
                const batch = documentIds.splice(0, 10);

                // add the batch request to to a queue
                batches.push(
                    new Promise(response => {
                        this.collection
                            .where(
                                window.firebase.firestore.FieldPath.documentId(),
                                'in',
                                [...batch]
                            )
                            .get()
                            .then(results => response(results.docs))
                    })
                )
            }

            // after all of the data is fetched, return it
            Promise.all(batches).then(content => {
                res(content.flat());
            })

        });
    }

    readData = (widgetId) => {
        return new Promise((resolve, reject) => {
            this.collection.doc(widgetId).get()
                .then(doc => {
                    if (doc.exists) {
                        return resolve(doc.data());
                    } else {
                        this.writeData(widgetId, {});
                        return resolve({});
                    }
                })
                .catch(err => reject(err));
        });
    }
}