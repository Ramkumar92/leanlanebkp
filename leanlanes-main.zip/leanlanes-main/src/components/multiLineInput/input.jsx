import { createRef, useEffect } from "react";
import Cancel from "../iconButtons/cancel";
import Okay from "../iconButtons/okay";

const MultiLineInput = ({ editable, value, onChange, onClose, onDoubleClick, largeInput, ...props }) => {

    const inputRef = createRef();

    useEffect(() => {
        if (editable) {
            var range = document.createRange()
            var sel = window.getSelection()

            range.setStart((inputRef.current.childNodes[0] || inputRef.current),
                inputRef.current.innerText.length);
            range.collapse(true);

            sel.removeAllRanges();
            sel.addRange(range);
        }
    }, [editable, inputRef])

    const handleBlur = () => {
        onChange(inputRef.current.innerText);
    }

    return (
        <div style={{ flexGrow: 1 }} onDoubleClick={() => {
            if (onDoubleClick) onDoubleClick()
        }}>
            {!editable &&
                <div style={{ minHeight: '32px', lineHeight: '24px' }}
                    className={largeInput ? 'miro-h3 font-500 line-height-28' : ''}>{value || ""}</div>
            }
            {editable &&
                <>
                    <div
                        style={{ minHeight: '32px', lineHeight: '24px' }}
                        ref={inputRef}
                        autoFocus
                        contentEditable={true}
                        suppressContentEditableWarning
                        {...props}
                        className={largeInput ? 'miro-h3 font-500' : ''}>
                        {value || ""}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Cancel className='text-preview__red-button'
                            onClick={() => onClose()} />
                        <Okay className='text-preview__blue-button'
                            onClick={handleBlur} />
                    </div>
                </>
            }
        </div>
    );
}

export default MultiLineInput;