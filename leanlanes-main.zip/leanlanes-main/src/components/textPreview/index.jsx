import { useEffect, useState } from 'react';
import ContextMenu from '../contextMenu';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { convertFromRaw, EditorState } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import './style.css';
import Cancel from '../iconButtons/cancel';
import Okay from '../iconButtons/okay';
import { useRef } from 'react';

const getDefaultText = (text) => ({
    "entityMap": {}, "blocks": [{
        "key": "637gr", text,
        "type": "unstyled", "depth": 0, "inlineStyleRanges": [], "entityRanges": [], "data": {}
    }]
});

const getEditorState = (text) => {
    if (!text) {
        return getDefaultText("Add description")
    }
    if (typeof (text) === "string") {
        return getDefaultText(text);
    }
    return text;
}

const TextPreview = ({ widgetId, text, onChange, mini }) => {
    const plainText = JSON.stringify(text || '');
    const [showContext, setShowContext] = useState(false);
    const [editable, setEditable] = useState(false);
    const [editorState, setEditorState] = useState(EditorState.createWithContent(convertFromRaw(getEditorState(text))));
    const contentStateRef = useRef(getEditorState(text));
    const checkPoint = useRef();

    useEffect(() => {
        setEditorState(EditorState.createWithContent(convertFromRaw(getEditorState(JSON.parse(plainText)))));
        contentStateRef.current = getEditorState(JSON.parse(plainText));
        setEditable(false);
    }, [plainText, widgetId]);

    const handleDoubleClick = () => {
        if (editable) return;
        checkPoint.current = contentStateRef.current;
        if (!text) {
            setEditorState(EditorState.createWithContent(convertFromRaw(getDefaultText(''))));
        }
        setEditable(true);
    }

    const handleSave = () => {
        setEditable(false);
        onChange(contentStateRef.current);
    }

    const handleCancel = () => {
        setEditable(false);
        setEditorState(EditorState.createWithContent(convertFromRaw(checkPoint.current)));
    }

    const handleKeyUp = (e) => {
        if (e.keyCode === 27) {
            handleCancel();
        }
    }

    return (
        <div className='text-preview__container' onDoubleClick={handleDoubleClick}>
            <div className="text-preview__text"
                onKeyUp={handleKeyUp}>
                <Editor
                    toolbarHidden={!editable}
                    readOnly={!editable}
                    editorState={editorState}
                    wrapperClassName="editor-wrapper"
                    editorClassName={mini ? "editor-read" : "editor-editor"}
                    onEditorStateChange={v => setEditorState(v)}
                    onContentStateChange={v => contentStateRef.current = v}
                    toolbar={{
                        options: ['blockType', 'inline', 'list'],
                        inline: { inDropdown: false },
                        blockType: { inDropdown: true }
                    }}
                />
                {(!editable && Boolean(text)) &&
                    <span className='text-preview__more-button'>
                        <MoreHorizontal onClick={() => setShowContext(true)} />
                    </span>
                }
                {(showContext && !editable) &&
                    <ContextMenu
                        className='leanstory__context_menu'
                        menuOptions={['Edit', 'Delete']}
                        onClose={(item) => {
                            setShowContext(false);
                            if (item === 'Edit') handleDoubleClick();
                            if (item === 'Delete') onChange('');
                        }}
                    />}
            </div>
            {editable &&
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Cancel className='text-preview__red-button'
                        onClick={handleCancel} />
                    <Okay className='text-preview__blue-button'
                        onClick={handleSave} />
                </div>
            }
        </div>
    )
}

export default TextPreview;