import './style.css';

const LabelChip = ({ label, description }) => {

    return (
        <div className='label-chip row-margin--mini'>
            <span className='label-chip--label'>{label}</span>
            {description}
        </div>
    );
}

export default LabelChip;