import { createRef, useEffect, useState } from 'react';
import Sortable from 'sortablejs';
import ContextMenu from '../contextMenu';
import ChevronRight from '../iconButtons/chevronRight';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import Input from '../input/input';
import './style.css';

const LaneList = ({ lanes = [], onChange, editable, showLaneDetail }) => {

    const [contextMenuIndex, setContextMenuIndex] = useState({ index: -1 });
    const [editIndex, setEditIndex] = useState(-1);
    const listRef = createRef();

    const array_move = (arr, old_index, new_index) => {
        if (new_index >= arr.length) {
            var k = new_index - arr.length + 1;
            while (k--) {
                arr.push(undefined);
            }
        }
        arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
        return arr;
    };

    const modifyLane = (action, index) => {
        switch (action) {
            case 'Delete':
                const newLanes = lanes.filter((_, laneIndex) => index !== laneIndex);
                onChange(newLanes);
                break;
            case 'Edit': setEditIndex(index);
                break;
            case 'Move up': onChange(array_move(lanes, index, index - 1));
                break;
            case 'Move down': onChange(array_move(lanes, index, index + 1));
                break;
            default: break;
        }
    }

    const handleTextChange = (text, editIdx) => {
        const newLanes = lanes.map((lane, index) => {
            if (index === editIdx) {
                return { ...lane, lane: text };
            }
            return lane;
        });
        onChange(newLanes);
    }

    const getMenuOptions = (index) => {
        if (lanes.length === 1) {
            return ['Edit', 'Delete'];
        }
        else if (index === 0) {
            return ['Edit', 'Move down', 'Delete'];
        }
        else if (index === lanes.length - 1) {
            return ['Edit', 'Move up', 'Delete'];
        }
        else {
            return ['Edit', 'Move up', 'Move down', 'Delete'];
        }

    }

    useEffect(() => {
        var sortable;
        const element = listRef.current;
        if (element && lanes.length) {
            sortable = new Sortable(element, {
                animation: 150,
                onEnd: function ({ oldIndex, newIndex }) {
                    onChange(array_move(lanes, oldIndex, newIndex));
                }
            });
        }
        return (() => {
            if (sortable) {
                sortable.destroy();
            }
        });
    }, [listRef, lanes, onChange]);

    const rowRenderer = ({ key, index }) => {
        return (
            <div key={lanes[index].lane + key}
                className={'lane-contents__row'}>
                <Input className='lane-contents__lane'
                    edit={editIndex === index}
                    value={lanes[index].lane}
                    onChange={v => handleTextChange(v, index)}
                    onClose={() => setEditIndex(-1)}
                />
                <div className='lane-contents__more'>
                    {editable
                        ? <MoreHorizontal
                            onClick={({ target }) => setContextMenuIndex({ index, target })}
                            className='lane-contents__lane--hover' />
                        : <ChevronRight
                            onClick={() => showLaneDetail(index)}
                        />
                    }
                </div>
                {contextMenuIndex.index === index &&
                    <ContextMenu
                        className={'lane-contents__context_menu'}
                        style={{
                            top: Math.min(contextMenuIndex.target.getBoundingClientRect().top,
                                window.innerHeight - 260
                            )
                        }}
                        menuOptions={getMenuOptions(index)}
                        onClose={action => {
                            setContextMenuIndex({ index: -1 });
                            if (action) modifyLane(action, index);
                        }}
                    />
                }
            </div>
        );
    }

    return (
        <div className='lane-contents__container'>
            <div ref={listRef}>
                {lanes.map((_, index) =>
                    rowRenderer({ key: index, index, style: { top: (index * 40), height: 40 } }))}
            </div>
            {!lanes.length &&
                <span className='lane-contents__no-lane'>Add a lane below</span>
            }
        </div>
    );
}

export default LaneList;