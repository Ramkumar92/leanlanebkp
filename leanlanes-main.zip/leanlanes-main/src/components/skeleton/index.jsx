import { Children } from 'react';
import './style.css';

const Skeleton = ({ children, isLoading, className }) => (
    <div className={className}>
        {Children.toArray(children).map((child, index) =>
            <div key={index} className={isLoading ? ' skeleton-animation' : ''}>
                {child}
            </div>
        )}
    </div>
);

export default Skeleton;