import { useState } from 'react';
import ContextMenu from '../contextMenu';
import Editor from '../iconButtons/editor';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import './style.css';

const CKEditorPreview = ({ onOpenSlide, onDelete }) => {

    const [showContext, setShowContext] = useState(false);

    return (
        <div className='iframe-preview__container'
            onClick={onOpenSlide}>
            <div className='iframe-preview__content'>
                <div className='miro-h6'>
                    editor
                </div>
                <Editor disabled
                    style={{ fill: '#000000' }}
                />
            </div>
            <span className='iframe-preview__more-button'>
                <MoreHorizontal onClick={e => {
                    e.preventDefault();
                    e.stopPropagation();
                    setShowContext(true);
                }} />
            </span>
            {showContext &&
                <ContextMenu
                    className='leanstory__context_menu'
                    menuOptions={['Delete']}
                    onClose={item => {
                        setShowContext(false);
                        if (item === 'Delete') onDelete();
                    }}
                />
            }
        </div>
    )
}

export default CKEditorPreview;