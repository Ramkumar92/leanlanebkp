import { useState } from 'react';
import { analyticsEvents } from '../../services/firebase/consts';
import './style.css';

const AddComment = ({ onChange }) => {

    const [comment, setComment] = useState("");
    const [user] = useState(window.firebaseUser?.displayName || "Anonymous");

    const handleSubmit = () => {
        let dateAdded = new Date();
        dateAdded = dateAdded.getHours() + ':' + dateAdded.getMinutes()
            + 'h ' + dateAdded.getDate() + '.' + (dateAdded.getMonth() + 1)
            + '.' + dateAdded.getFullYear();
        onChange({ user, comment, dateAdded });
        setComment("");
        window.firebase.analytics().logEvent(analyticsEvents.add_comment);
    }

    return (
        <div className='addlink__container'>

            <input className="miro-input miro-input--primary miro-input--small width-100 row-margin--mini"
                placeholder="Add comment"
                value={comment}
                onChange={e => setComment(e.target.value)}
            />

            {/* <input className="miro-input miro-input--primary miro-input--small width-100 row-margin--mini"
                placeholder="Name or post anonymously"
                value={user}
                onChange={e => setUser(e.target.value)}
            /> */}

            <div className='addlink__footer row-margin--mini'>
                <button
                    disabled={!Boolean(comment)}
                    onClick={handleSubmit}
                    className='button button-small addlink__footer--link-button'
                >
                    Add Comment
                </button>
            </div>
        </div>
    );
}

export default AddComment;