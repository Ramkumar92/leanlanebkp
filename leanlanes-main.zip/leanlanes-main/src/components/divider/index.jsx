import './style.css';

const Divider = () => <div className='divider' />

export default Divider;