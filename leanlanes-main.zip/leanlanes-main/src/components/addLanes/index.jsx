import { useState } from 'react';
import './style.css';

const AddLanes = ({ onChange }) => {

    const [lane, setLane] = useState("");

    const handleSubmit = () => {
        onChange(lane);
        setLane("");
    }

    return (
        <div className='addlane__container'>

            <input className="miro-input miro-input--primary miro-input--small width-100 row-margin--mini"
                placeholder="Add LeanLane name"
                value={lane}
                onChange={e => setLane(e.target.value)}
            />

            <div className='addlane__footer row-margin--mini'>
                <div className='addlane__footer--text .miro-p-small'>
                    Add new LeanLanes to present flows
                </div>
                <div className='addlane__footer--button'>
                    <button
                        disabled={!Boolean(lane)}
                        onClick={handleSubmit}
                        className='miro-btn miro-btn--primary miro-btn--small addlane__footer--link-button'
                    >
                        + LeanLane
                    </button>
                </div>
            </div>
        </div>
    );
}

export default AddLanes;