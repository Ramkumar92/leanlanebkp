import './style.css';

const AddStories = ({ deferSelection, setDeferSelection }) => {

    return (
        <div className='addstories__container'>
            <div className='addstories__footer row-margin--mini'>
                {deferSelection ?
                    <button
                        onClick={() => setDeferSelection(false)}
                        className='button button-small addstories__footer--stop-button'
                    >
                        Stop
                    </button>
                    :
                    <button
                        onClick={() => setDeferSelection(true)}
                        className='button button-small addstories__footer--add-button'
                    >
                        Select Cards
                    </button>
                }
            </div>
        </div>
    );
}

export default AddStories;