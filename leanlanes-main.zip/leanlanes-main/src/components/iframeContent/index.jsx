import './style.css';

const IframeContent = ({ iframeCode }) => {

    const fullscreenCode =
        iframeCode.replace('width=', 'oldWidth=')
            .replace('height=', 'oldHeight=')
            .replace('<iframe', '<iframe style="width: 100%; height: 95vh;"');

    return (
        <iframe
            frameBorder="0"
            samesite="none"
            secure="true"
            className="iframe-content"
            title="container"
            srcDoc={fullscreenCode} />
    )
}

export default IframeContent;