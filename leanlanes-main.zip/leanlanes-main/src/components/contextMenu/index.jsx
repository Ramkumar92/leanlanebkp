import { useEffect } from 'react';
import './style.css';

const ContextMenu = ({ rowStyles, menuOptions, onClose, className = "", ...props }) => {

    useEffect(() => {
        const handleClose = () => {
            onClose();
        }
        window.addEventListener('click', handleClose);
        return (() => {
            window.removeEventListener('click', handleClose);
        });
    }, [onClose]);

    return (
        <div className={'context-menu__container ' + className} {...props}>
            {menuOptions.map((menuItem, index) =>
                <div className='context-menu__item'
                    style={rowStyles?.[index]}
                    key={menuItem}
                    onClick={e => {
                        e.preventDefault();
                        e.stopPropagation();
                        onClose(menuItem);
                    }}>
                    {menuItem}
                </div>
            )}
        </div>
    )
}

export default ContextMenu;