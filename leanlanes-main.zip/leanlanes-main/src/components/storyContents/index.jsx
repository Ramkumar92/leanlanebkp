import { createRef, useContext, useEffect, useState } from 'react';
import { focusWidgetById, selectWidget } from '../../services/miro/manipulate';
import { AppContext } from '../../store';
import ContextMenu from '../contextMenu';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import Sortable from 'sortablejs';
import './style.css';

const StoryContents = ({ stories = [], onChange, readOnly }) => {

    const [contextMenuIndex, setContextMenuIndex] = useState({ index: -1 });
    const [{ widgetTitles }] = useContext(AppContext);
    const listRef = createRef();

    const handleStoryClick = (id) => {
        focusWidgetById(id)
        selectWidget(id);
    }

    const getHeight = () => window.innerHeight - 275;

    const getMenuOptions = (index) => {
        if (stories.length === 1) {
            return ['Delete'];
        }
        else if (index === 0) {
            return ['Delete', 'Move down'];
        }
        else if (index === stories.length - 1) {
            return ['Delete', 'Move up'];
        }
        else {
            return ['Delete', 'Move up', 'Move down'];
        }
    }

    const array_move = (arr, old_index, new_index) => {
        if (new_index >= arr.length) {
            var k = new_index - arr.length + 1;
            while (k--) {
                arr.push(undefined);
            }
        }
        arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
        return arr;
    };

    useEffect(() => {
        var sortable;
        const element = listRef.current;
        if (element && stories.length) {
            sortable = new Sortable(element, {
                animation: 150,
                onEnd: function ({ oldIndex, newIndex }) {
                    onChange(array_move(stories, oldIndex, newIndex));
                }
            });
        }
        return (() => {
            if (sortable) {
                sortable.destroy();
            }
        });
    }, [listRef, stories, onChange]);

    const modifyStory = (action, index) => {
        switch (action) {
            case 'Delete':
                const newStories = stories.filter((_, laneIndex) => index !== laneIndex);
                onChange(newStories);
                break;
            case 'Move up': onChange(array_move(stories, index, index - 1));
                break;
            case 'Move down': onChange(array_move(stories, index, index + 1));
                break;
            default: break;
        }
    }

    return (
        <div style={{ maxHeight: getHeight(), overflow: 'auto' }} ref={listRef}>
            {stories.map((story, index) =>
                <div key={story.id} className='story-contents__row' >
                    <div className='story-contents__story'
                        onClick={() => handleStoryClick(story.id)}
                        dangerouslySetInnerHTML={{
                            __html: widgetTitles[story.id]?.title || story.title
                        }}
                    />
                    {!readOnly &&
                        <div className='story-contents__more'>
                            <MoreHorizontal
                                onClick={({ target }) => setContextMenuIndex({ index, target })}
                            />
                        </div>
                    }
                    {contextMenuIndex.index === index &&
                        <ContextMenu
                            className='leanstory__context_menu'
                            style={{ top: contextMenuIndex.target.getBoundingClientRect().top }}
                            menuOptions={getMenuOptions(index)}
                            onClose={action => { setContextMenuIndex({ index: -1 }); if (action) modifyStory(action, index); }}
                        />
                    }
                </div>
            )}
        </div>
    );
}

export default StoryContents;