import { createRef, useState } from 'react';
import ContextMenu from '../contextMenu';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import Upload from '../iconButtons/upload';
import SimpleMultiLineInputDialog from '../simpleMultiLineInputDialog';
import './style.css';

const ImageUpload = ({ onChange, handleIframeContent, handleEditor }) => {

    const inputFileRef = createRef();
    const [showContext, setShowContext] = useState(false);
    const [showDialog, setShowDialog] = useState(false);

    const processUpload = (file) => {
        var reader = new FileReader();
        reader.onload = function () {
            var dataURL = reader.result;
            onChange(dataURL);
        };
        reader.readAsDataURL(file);
    }

    const handleUpload = (e) => {
        if (e.target.files.length) {
            processUpload(e.target.files[0]);
        }
    }

    const handleDrop = (e) => {
        e.preventDefault();
        processUpload(e.dataTransfer.files[0]);
        e.target.classList.remove('image-upload__container--dragover')
    }

    const handleIframeDialogClose = (iframeCode) => {
        setShowDialog(false);
        if (iframeCode) handleIframeContent(iframeCode);
    }

    return (
        <div className='image-upload__container'
            onClick={() => { if (!showContext && !showDialog) inputFileRef.current.click() }}
            onDragOver={e => {
                e.preventDefault();
                e.target.classList.add('image-upload__container--dragover');
            }}
            onDragLeave={e => e.target.classList.remove('image-upload__container--dragover')}
            onDrop={handleDrop}>
            <input
                style={{ display: 'none' }}
                ref={inputFileRef}
                onChange={handleUpload}
                type='file'
                accept="image/*" />
            <div className='image-upload__content'>
                <div className='miro-h6 disabled-font-color'>
                    Upload Image
                </div>
                <Upload disabled />
            </div>
            <span className='image-upload__more-button'>
                <MoreHorizontal onClick={e => {
                    setShowContext(true);
                    e.preventDefault();
                    e.stopPropagation();
                }} />
            </span>
            {showContext &&
                <ContextMenu
                    className='image_upload__context_menu'
                    menuOptions={['Load iframe', 'Upload Image', 'Add editor']}
                    onClose={item => {
                        setShowContext(false);
                        if (item === 'Load iframe') setShowDialog(true);
                        if (item === 'Upload Image') inputFileRef.current.click();
                        if (item === 'Add editor') handleEditor();
                    }}
                />
            }
            {showDialog &&
                <SimpleMultiLineInputDialog
                    description={'Paste iframe code'}
                    onClose={handleIframeDialogClose}
                    rows={4}
                />
            }
        </div>
    )
}

export default ImageUpload;