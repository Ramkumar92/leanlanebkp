import { createRef, useContext, useEffect, useState } from 'react';
import Sortable from 'sortablejs';
import { focusStory, focusWidgetById, selectWidget, updateWidgetText } from '../../services/miro/manipulate';
import { AppContext } from '../../store';
import { setWidgetTitles } from '../../store/actions/selection';
import ContextMenu from '../contextMenu';
import Error from '../iconButtons/error';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import Input from '../input/input';
import SimpleInputDialog from '../simpleInputDialog';
import './style.css';

const StoryList = ({ stories = [], onChange }) => {

    const [{ widgetTitles }, dispatch] = useContext(AppContext);
    const [contextMenuIndex, setContextMenuIndex] = useState({ index: -1 });
    const [showOverride, setShowOverride] = useState(null);
    const [editIndex, setEditIndex] = useState(-1);
    const listRef = createRef();

    const array_move = (arr, old_index, new_index) => {
        if (new_index >= arr.length) {
            var k = new_index - arr.length + 1;
            while (k--) {
                arr.push(undefined);
            }
        }
        arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
        return arr;
    };

    const modifyLane = (action, index) => {
        switch (action) {
            case 'Select': focusWidgetById(stories[index].id);
                selectWidget(stories[index].id);
                break;
            case 'Delete':
                const newStories = stories.filter((_, laneIndex) => index !== laneIndex);
                onChange(newStories);
                break;
            case 'Edit': setEditIndex(index);
                break;
            case 'Move up': onChange(array_move(stories, index, index - 1));
                break;
            case 'Move down': onChange(array_move(stories, index, index + 1));
                break;
            case 'Override': setShowOverride({ index });
                break;
            case 'Remove Override': removeOverride(index);
                break;
            default: break;
        }
    }

    const handleOverride = (overRideText) => {
        if (overRideText) {
            const newStories = stories.map((story, storyIndex) => {
                if (storyIndex === showOverride.index) {
                    return { ...story, overRideText }
                }
                return story;
            });
            onChange(newStories);
        }
        setShowOverride(null);
    }

    const handleOverrideTextChange = (overRideText, index) => {
        if (overRideText) {
            const newStories = stories.map((story, storyIndex) => {
                if (storyIndex === index) {
                    return { ...story, overRideText }
                }
                return story;
            });
            onChange(newStories);
        }
    }

    const removeOverride = (index) => {
        const newStories = stories.map((story, storyIndex) => {
            if (storyIndex === index) {
                delete story.overRideText;
                return story;
            }
            return story;
        });
        onChange(newStories);
    }

    const handleTextChange = (text, editIdx) => {

        if (stories[editIdx].overRideText) {
            handleOverrideTextChange(text, editIdx);
            return;
        }

        const newStories = stories.map((story, index) => {
            if (index === editIdx) {
                return { ...story, text };
            }
            return story;
        });
        updateWidgetText(stories[editIdx].id, text);
        let newWidgetTitles = { ...widgetTitles };
        newWidgetTitles[stories[editIdx].id] = {
            ...widgetTitles[stories[editIdx].id],
            plainText: text
        };
        dispatch(setWidgetTitles(newWidgetTitles));
        onChange(newStories);
    }

    const getMenuOptions = (index) => {
        const overRideText = stories[index].overRideText ? 'Remove Override' : 'Override';
        if (stories.length === 1) {
            return ['Select', overRideText, 'Edit', 'Delete'];
        }
        else if (index === 0) {
            return ['Select', overRideText, 'Edit', 'Delete', 'Move down'];
        }
        else if (index === stories.length - 1) {
            return ['Select', overRideText, 'Edit', 'Delete', 'Move up'];
        }
        else {
            return ['Select', overRideText, 'Edit', 'Delete', 'Move up', 'Move down'];
        }
    }

    useEffect(() => {
        var sortable;
        const element = listRef.current;
        if (element && stories.length) {
            sortable = new Sortable(element, {
                animation: 150,
                onEnd: function ({ oldIndex, newIndex }) {
                    onChange(array_move(stories, oldIndex, newIndex));
                }
            });
        }
        return (() => {
            if (sortable) {
                sortable.destroy();
            }
        });
    }, [listRef, stories, onChange]);

    const rowRenderer = ({ index }) => {
        return (
            <div key={stories[index].id}
                className={'lane-contents__row'}>
                {(stories[index].text === '(Deleted)') &&
                    <Error className='lane-contents__error-button' />
                }
                <Input className={'lane-contents__lane'
                    + (stories[index].overRideText ? ' lane-contents__lane--blue' : '')}
                    style={{ pointerEvents: (editIndex === index ? 'auto' : 'none') }}
                    edit={editIndex === index}
                    value={stories[index].overRideText
                        || widgetTitles[stories[index].id]?.plainText
                        || stories[index].text}
                    onChange={v => handleTextChange(v, index)}
                    onClose={() => setEditIndex(-1)}
                    onClick={() => focusStory(stories[index].id)}
                />
                <div className='lane-contents__more'>
                    <MoreHorizontal
                        onClick={({ target }) => setContextMenuIndex({ index, target })}
                        className='lane-contents__lane--hover' />

                </div>
                {contextMenuIndex.index === index &&
                    <ContextMenu
                        className={'lane-contents__context_menu'}
                        style={{
                            top: Math.min(contextMenuIndex.target.getBoundingClientRect().top,
                                window.innerHeight - 260
                            )
                        }}
                        rowStyles={[{}, {
                            borderBottom: '1px solid',
                            borderImage: 'linear-gradient(to right, white 12%, #cdccd7 1%, #cdccd7 70%, #cdccd7 1%, white 10%) 1'
                        }, {}, {
                            borderBottom: '1px solid',
                            borderImage: 'linear-gradient(to right, white 12%, #cdccd7 1%, #cdccd7 70%, #cdccd7 1%, white 10%) 1',
                            color: 'var(--basic-red)'
                        }, {}, {}]}
                        menuOptions={getMenuOptions(index)}
                        onClose={action => {
                            setContextMenuIndex({ ...contextMenuIndex, index: -1 });
                            if (action) modifyLane(action, index);
                        }}
                    />
                }
                {showOverride && showOverride.index === index &&
                    <SimpleInputDialog
                        style={{
                            top: Math.min(contextMenuIndex.target.getBoundingClientRect().top,
                                window.innerHeight - 148
                            )
                        }}
                        description={'Provide an override name to replace the LeanStory default name'}
                        onClose={v => handleOverride(v)}
                    />
                }
            </div>
        );
    }

    return (
        <div className='lane-contents__container'>
            <div ref={listRef}>
                {stories.map((_, index) =>
                    rowRenderer({ key: index, index, style: { top: (index * 40), height: 40 } }))}
            </div>
        </div>
    );
}

export default StoryList;