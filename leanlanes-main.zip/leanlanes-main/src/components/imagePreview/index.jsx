import { createRef, useState } from 'react';
import ContextMenu from '../contextMenu';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import './style.css';

const ImagePreview = ({ image, onDelete, onChange, onClick, ignoreFixedHeight }) => {

    const [showContext, setShowContext] = useState(false);
    const inputFileRef = createRef();

    const processUpload = (file) => {
        var reader = new FileReader();
        reader.onload = function () {
            var dataURL = reader.result;
            onChange(dataURL);
        };
        reader.readAsDataURL(file);
    }

    const handleUpload = (e) => {
        if (e.target.files.length) {
            processUpload(e.target.files[0]);
        }
    }

    const handleDrop = (e) => {
        e.preventDefault();
        processUpload(e.dataTransfer.files[0]);
        e.target.classList.remove('image-upload__container--dragover')
    }

    return (
        <div className={ignoreFixedHeight ? 'image-preview__container--dynamic' : 'image-preview__container'}
            onDragOver={e => {
                e.preventDefault();
                e.target.classList.add('image-upload__container--dragover');
            }}
            onDragLeave={e => e.target.classList.remove('image-upload__container--dragover')}
            onDrop={handleDrop}>
            <input
                style={{ display: 'none' }}
                ref={inputFileRef}
                onChange={handleUpload}
                type='file'
                accept="image/*" />
            <img className={ignoreFixedHeight ? 'image-preview__image--dynamic' : 'image-preview__image'}
                onClick={onClick}
                alt={"Leanstory"}
                loading="lazy"
                src={image}
            />
            <span className='image-preview__more-button'>
                <MoreHorizontal onClick={() => setShowContext(true)} />
            </span>
            {showContext &&
                <ContextMenu
                    className='leanstory__context_menu'
                    menuOptions={['Delete']}
                    onClose={item => {
                        setShowContext(false);
                        if (item === 'Delete') onDelete();
                    }}
                />
            }
        </div>
    )
}

export default ImagePreview;