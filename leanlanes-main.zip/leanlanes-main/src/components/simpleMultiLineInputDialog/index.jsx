import { useState } from 'react';
import Cancel from '../iconButtons/cancel';
import Okay from '../iconButtons/okay';
import './style.css';

const SimpleMultiLineInputDialog = ({ iframe, rows, onClose, description }) => {

    const [inputValue, setInputValue] = useState((iframe || ''));

    const handleClose = () => {
        if (inputValue.length) onClose(inputValue);
    }

    return (
        <div className='box-shadow simple-dialog'
            onClick={e => { e.preventDefault(); e.stopPropagation(); }}>
            <div className='row-margin column-margin miro-p-small color-grey50'>
                {description}
            </div>
            <div className='column-margin'>
                <textarea
                    value={inputValue}
                    spellCheck={false}
                    rows={rows || 1}
                    className='simple-dialog__multiline-input width-100 font-500'
                    onChange={e => setInputValue(e.target.value)}
                    placeholder="Paste code" />
            </div>
            <div className='row-margin--small column-margin float-right flex'>
                <Cancel className='text-preview__red-button'
                    onClick={() => onClose()} />
                <Okay className='text-preview__blue-button'
                    disabled={!Boolean(inputValue)}
                    onClick={handleClose} />
            </div>
        </div>
    );
}

export default SimpleMultiLineInputDialog;