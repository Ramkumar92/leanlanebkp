import './style.css';
import { CKEditor as Editor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

var timeOut;
const debounce = (data, func, delay) => {
    if (timeOut) {
        clearTimeout(timeOut);
    }
    timeOut = setTimeout(() => func(data), delay);
}

const CKEditor = ({ editorText, saveChanges }) => {

    return (
        <Editor
            editor={ClassicEditor}
            data={editorText}
            config={{
                toolbar: ['heading', '|', 'bold', 'italic', 'blockQuote', 'link', 'numberedList',
                    'bulletedList', 'imageUpload', 'insertTable', 'alignment', '|', 'undo', 'redo'],
                table: {
                    contentToolbar: ['tableRow', 'tableColumn', 'mergeTableCells']
                }
            }}
            onReady={(editor) => {
                editor.editing.view.change((writer) => {
                    writer.setStyle(
                        "height",
                        "90vh",
                        editor.editing.view.document.getRoot()
                    );
                });
            }}
            onChange={(_, editor) => debounce(editor.getData(), saveChanges, 2000)}
        />
    )
}

export default CKEditor;