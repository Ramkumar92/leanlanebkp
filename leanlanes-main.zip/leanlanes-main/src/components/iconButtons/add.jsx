import './style.css'

const Add = ({ disabled, className, ...props }) => (
    <svg xmlns="http://www.w3.org/2000/svg"
        className={"icon-button" + (disabled ? " icon-button--disabled " : " ")
            + (className || "")}
        height="24px"
        viewBox="0 0 24 24"
        width="24px"
        {...props}
    >
        <path d="M0 0h24v24H0z" fill="none" />
        <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
    </svg>
);


export default Add;