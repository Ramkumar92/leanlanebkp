import './style.css'

const MoreHorizontal = ({ disabled, className, ...props }) => (
    <svg xmlns="http://www.w3.org/2000/svg"
        className={"icon-button" + (disabled ? " icon-button--disabled " : " ")
            + (className || "")}
        height="24px"
        viewBox="0 0 24 24"
        width="24px"
        {...props}>
        <path d="M0 0h24v24H0V0z" fill="none" />
        <path d="M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
    </svg>
);


export default MoreHorizontal;