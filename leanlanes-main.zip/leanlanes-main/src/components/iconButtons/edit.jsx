import './style.css'

const Edit = ({ disabled, className, ...props }) => (
    <svg xmlns="http://www.w3.org/2000/svg"
        className={"icon-button" + (disabled ? " icon-button--disabled " : " ")
            + (className || "")}
        height="24px"
        viewBox="0 0 24 24"
        width="24px"
        {...props}
    >
        <path d="M18.01,12.87l.71-.71a1,1,0,0,1,1.41,0l.71.71a1,1,0,0,1,0,1.41l-.71.71Zm-.71.71L12,18.88V21h2.12l5.3-5.3Z" />
        <path d="M-2609.7-2074h-.3a2,2,0,0,1-2-2v-14a2,2,0,0,1,2-2h14a2,2,0,0,1,2,2v.923l-2,1.921V-2090h-14v3h13.839l-2.082,2H-2610v4h7.592l-2.082,2H-2610v3h2.387l-2.083,2Z" transform="translate(2615 2095)" />
    </svg>
);


export default Edit;