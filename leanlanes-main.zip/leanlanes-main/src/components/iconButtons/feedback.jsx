import './style.css';

const FeedbackButton = ({ className, ...props }) => {

    return (
        <button
            style={{ float: 'right', width: 120 , display: 'flex'}}
            className={'button button-small icon-button' + (className || '')}
            {...props}
        >
            <p className="p-medium icon-button__label">Feedback</p>
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px"
                className="icon-button__icon">
                <path d="M0 0h24v24H0V0z" fill="none" />
                <path
                    d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17l-.59.59-.58.58V4h16v12zm-9-4h2v2h-2zm0-6h2v4h-2z" />
            </svg>
        </button>
    );
}

export default FeedbackButton;