import { createRef, useEffect, useState } from "react";

var timer = null;
const Input = ({ value, onChange, onClick, onClose, multiLine, edit, ...props }) => {

    const [editable, setEditable] = useState(false);
    const [inputValue, setInputValue] = useState(value);
    const inputRef = createRef();

    useEffect(() => setInputValue(value), [value]);

    useEffect(() => {
        if (editable || edit) {
            inputRef.current.focus();
            // inputRef.current.setSelectionRange(100, 100);
        }
    }, [edit, editable, inputRef])

    const handleBlur = () => {
        setEditable(false);
        if (value !== inputValue) onChange(inputValue);
        if (onClose) onClose();
    }

    const handleClick = () => {
        if (!onClick) return;
        if (timer) {
            clearTimeout(timer);
            timer = null;
        }
        else {
            timer = setTimeout(() => { onClick(); timer = null }, 300);
        }
    }

    return (
        <div
            onDoubleClick={() => setEditable(true)}
            onClick={editable ? undefined : handleClick}
            className='flex flex-grow'>
            {(editable || edit || !multiLine) ?
                <input
                    ref={inputRef}
                    value={inputValue || ""}
                    spellCheck={false}
                    autoFocus
                    onChange={e => setInputValue(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') handleBlur() }}
                    onBlur={handleBlur}
                    disabled={!editable && !edit}
                    {...props}
                />
                :
                <span {...props}>
                    {inputValue}
                </span>
            }
        </div>
    );
}

export default Input;