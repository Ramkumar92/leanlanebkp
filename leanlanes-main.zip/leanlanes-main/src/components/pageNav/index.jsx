import ChevronLeft from '../iconButtons/chevronLeft';
import ChevronRight from '../iconButtons/chevronRight';
import './style.css';

const PageNav = ({ total, currentIndex, onChange }) => {

    const canNavigateNext = () => !(total < currentIndex + 2);
    const canNavigatePrevious = () => Boolean(currentIndex);

    return (
        <div className='pagenav__footer row-margin--mini'>
            <div className='pagenav__footer--button'>
                <div className="grid-container pagenav__footer--link-button">
                    <div className="chevron-left">
                        <ChevronLeft
                            className={'pagenav__button'}
                            disabled={!canNavigatePrevious()}
                            onClick={() => { if (canNavigatePrevious()) onChange(currentIndex - 1) }}
                        />
                    </div>
                    <div className="counter">
                        {currentIndex + 1} of {total}
                    </div>
                    <div className="chevron-right">
                        <ChevronRight
                            className={'pagenav__button'}
                            disabled={!canNavigateNext()}
                            onClick={() => { if (canNavigateNext()) onChange(currentIndex + 1) }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PageNav;