import { useState } from 'react';
import ContextMenu from '../contextMenu';
import Code from '../iconButtons/code';
import MoreHorizontal from '../iconButtons/moreHorizontal';
import SimpleMultiLineInputDialog from '../simpleMultiLineInputDialog';
import './style.css';

const IframePreview = ({ iframe, onOpenSlide, onDelete, handleIframeContent }) => {

    const [showContext, setShowContext] = useState(false);
    const [showDialog, setShowDialog] = useState(false);

    const handleIframeDialogClose = (iframeCode) => {
        setShowDialog(false);
        if (iframeCode) handleIframeContent(iframeCode);
    }

    return (
        <div className='iframe-preview__container'
            onClick={onOpenSlide}>
            <div className='iframe-preview__content'>
                <div className='miro-h6'>
                    iframe
                </div>
                <Code disabled
                    style={{ fill: '#000000' }}
                />
            </div>
            <span className='iframe-preview__more-button'>
                <MoreHorizontal onClick={e => {
                    e.preventDefault();
                    e.stopPropagation();
                    setShowContext(true);
                }} />
            </span>
            {showContext &&
                <ContextMenu
                    className='leanstory__context_menu'
                    menuOptions={['Edit', 'Delete']}
                    onClose={item => {
                        setShowContext(false);
                        if (item === 'Delete') onDelete();
                        if (item === 'Edit') setShowDialog(true);
                    }}
                />
            }
            {showDialog &&
                <SimpleMultiLineInputDialog
                    iframe={iframe}
                    description={'Paste iframe code'}
                    onClose={handleIframeDialogClose}
                    rows={4}
                />
            }
        </div>
    )
}

export default IframePreview;