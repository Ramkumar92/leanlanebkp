import { useEffect, useState } from 'react';
import { analyticsEvents } from '../../services/firebase/consts';
import { sanitizeUrl } from '../../utils/sanitize';
import './style.css';

const AddLink = ({ onChange, defaultTitle, defaultLink }) => {

    const [linkTitle, setLinkTitle] = useState(defaultTitle || "");
    const [link, setLink] = useState(defaultLink || "");

    useEffect(() => {
        if (defaultLink) setLink(defaultLink);
        if (defaultTitle) setLinkTitle(defaultTitle);
    }, [defaultTitle, defaultLink]);

    const handleSubmit = () => {
        let dateAdded = new Date();
        dateAdded = dateAdded.getDate() + '.' + (dateAdded.getMonth() + 1) + '.' + dateAdded.getFullYear();
        onChange({ dateAdded, linkTitle, link });
        setLinkTitle("");
        setLink("");
        window.firebase.analytics().logEvent(analyticsEvents.add_link);
    }

    return (
        <div className='addlink__container'>

            <input className="miro-input miro-input--primary miro-input--small width-100 row-margin--mini"
                placeholder="Add link title"
                value={linkTitle}
                onChange={e => setLinkTitle(e.target.value)}
            />

            <input className="miro-input miro-input--primary miro-input--small width-100 row-margin--mini"
                placeholder="Paste link"
                value={link}
                onChange={e => setLink(e.target.value)}
            />

            <div className='addlink__footer row-margin--mini'>
                <button
                    disabled={!Boolean(linkTitle) || !Boolean(link) || !Boolean(sanitizeUrl(link))}
                    onClick={handleSubmit}
                    className='button button-small addlink__footer--link-button'
                >
                    {(defaultTitle || defaultLink) ? 'save edit' : 'Add Link'}
                </button>
            </div>
        </div>
    );
}

export default AddLink;