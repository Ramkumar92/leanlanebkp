import { useState } from 'react';
import Cancel from '../iconButtons/cancel';
import Okay from '../iconButtons/okay';
import Input from '../input/input';
import './style.css';

const SimpleInputDialog = ({ onClose, description , ...props}) => {

    const [inputValue, setInputValue] = useState('');

    const handleClose = () => {
        if (inputValue.length) onClose(inputValue);
    }

    return (
        <div className='box-shadow simple-dialog' {...props}>
            <div className='row-margin column-margin miro-p-small color-grey50'>
                {description}
            </div>
            <div className='column-margin'>
                <Input
                    className='simple-dialog__input width-100'
                    onChange={v => setInputValue(v)}
                    edit />
            </div>
            <div className='row-margin--small column-margin float-right flex'>
                <Cancel className='text-preview__red-button'
                    onClick={() => onClose()} />
                <Okay className='text-preview__blue-button'
                    disabled={!Boolean(inputValue)}
                    onClick={handleClose} />
            </div>
        </div>
    );
}

export default SimpleInputDialog;