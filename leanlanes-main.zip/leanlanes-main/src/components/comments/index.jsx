import './style.css';
import ContextMenu from '../contextMenu';
import Input from '../input/input';
import { useState } from 'react';
import MoreHorizontal from '../iconButtons/moreHorizontal';

const Comments = ({ comments = [], updateComments, readOnly, largeRow }) => {

    const [contextMenuIndex, setContextMenuIndex] = useState({ index: -1 });
    const [editIndex, setEditIndex] = useState(-1);

    const handleDelete = (index) => {
        updateComments((comments || []).filter((_, idx) => index !== idx));
    }

    const handleCommentChange = (comment, index) => {
        updateComments((comments || []).map((commentData, idx) => {
            if (index === idx) {
                return { ...commentData, comment };
            }
            return commentData;
        }));
    }

    const getHeight = () => {
        return window.innerHeight - 300;
    }

    return (
        <div style={{ maxHeight: getHeight(), overflow: 'auto' }}>
            {comments.map(({ dateAdded, user, comment }, index) =>
                <div key={dateAdded} className='link-contents flex'>
                    <div className='flex-grow'>
                        {editIndex === index
                            ?
                            <Input className={'link-contents__comment'}
                                edit={true}
                                value={comment}
                                onChange={v => handleCommentChange(v, index)}
                                onClose={() => setEditIndex(-1)}
                            />
                            :
                            <div className={'link-contents__comment'}
                                onDoubleClick={() => setEditIndex(index)}>
                                {comment}
                            </div>
                        }
                        <div className='link-contents__comment_date'>
                            {'- ' + (user || 'Anonymous') + ', ' + dateAdded}
                        </div>
                    </div>
                    {!readOnly &&
                        <div className='link-contents__more_icon'>
                            <MoreHorizontal onClick={({ target }) => setContextMenuIndex({ index, target })} />
                        </div>
                    }
                </div>
            )}
            {contextMenuIndex.index > -1 &&
                <ContextMenu
                    style={{ top: contextMenuIndex.target.getBoundingClientRect().top }}
                    className={'link-contents__context_menu'}
                    menuOptions={['Edit', 'Delete']}
                    onClose={action => {
                        if (action === 'Edit') setEditIndex(contextMenuIndex.index);
                        if (action === 'Delete') handleDelete(contextMenuIndex.index);
                        setContextMenuIndex({ index: -1 });
                    }}
                />
            }
        </div >
    );
}

export default Comments;