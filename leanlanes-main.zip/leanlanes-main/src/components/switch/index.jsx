import './style.css';

const Switch = ({ options, active, setActive }) => {
    return (
        <div className='switch__container'>
            {options.map(option =>
                <div key={option}
                    className={'switch__container--option '
                        + (active === option ? 'switch__container--active' : '')}
                    onClick={() => setActive(option)}>
                    {option}
                </div>
            )}
        </div>
    )
}

export default Switch;