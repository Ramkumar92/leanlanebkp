import MoreHorizontal from '../iconButtons/moreHorizontal';
import { AutoSizer, List } from 'react-virtualized';
import './style.css';
import ContextMenu from '../contextMenu';
import { useContext, useState } from 'react';
import { setClipboardData } from '../../store/actions/selection';
import { AppContext } from '../../store';
import { focusWidgetById } from '../../services/miro/manipulate';
import qs from 'qs';

const LinkContents = ({ links = [], updateLinks, readOnly, largeRow, setEditLink }) => {

    const [{ boardInfo: { id: boardId } }, dispatch] = useContext(AppContext);
    const [contextMenuIndex, setContextMenuIndex] = useState({ index: -1 });

    const getMenuOptions = (index) => {
        if (links.length === 1) {
            return ['Cut', 'Copy', 'Edit', 'Delete'];
        }
        else if (index === 0) {
            return ['Cut', 'Copy', 'Edit', 'Move down', 'Delete'];
        }
        else if (index === links.length - 1) {
            return ['Cut', 'Copy', 'Edit', 'Move up', 'Delete'];
        }
        else {
            return ['Cut', 'Copy', 'Edit', 'Move up', 'Move down', 'Delete'];
        }

    }

    const handleAction = (action, index) => {
        const neWLinks = Array.from(links);
        switch (action) {
            case 'Edit': setEditLink({
                title: links[index].linkTitle,
                link: links[index].link,
                index
            });
                break;
            case 'Move up':
                neWLinks[index - 1] = links[index];
                neWLinks[index] = links[index - 1];
                updateLinks(neWLinks);
                break;
            case 'Move down':
                neWLinks[index + 1] = links[index];
                neWLinks[index] = links[index + 1];
                updateLinks(neWLinks);
                break;
            case 'Delete': updateLinks((links || []).filter((_, idx) => index !== idx));
                break;
            case 'Cut': dispatch(setClipboardData({ link: links[index] }));
                updateLinks((links || []).filter((_, idx) => index !== idx));
                break;
            case 'Copy': dispatch(setClipboardData({ link: links[index] }));
                break;
            default: break;
        }
    }

    const handleLinkClick = (e, link) => {
        if (link.startsWith('https://miro.com/app/board/' + boardId) && link.includes('moveToWidget=')) {
            e.preventDefault();
            e.stopPropagation();
            const { moveToWidget } = qs.parse(link.split('?')[1]);
            focusWidgetById(moveToWidget);
        }
    }

    function rowRenderer({ key, index, style }) {
        return (
            <div key={key} style={style} className='link-contents__row'>
                <div className='link-contents__date'>
                    {links[index].dateAdded}
                </div>
                <a className='link-contents__link'
                    href={links[index].link}
                    target='_blank'
                    onClick={e => handleLinkClick(e, links[index].link)}
                    rel="noreferrer">
                    {links[index].linkTitle}
                </a>
                {!readOnly &&
                    <div className='link-contents__more'>
                        <MoreHorizontal onClick={({ target }) => setContextMenuIndex({ index, target })} />
                    </div>
                }
            </div>
        );
    }

    const getHeight = () => {
        const linksHeight = links.length * 32;
        const availableHeight = window.innerHeight - 275;
        return Math.min(linksHeight, availableHeight);
    }

    return (
        <div style={{ height: getHeight() }}>
            <AutoSizer>
                {({ height, width }) => (
                    <List
                        height={height}
                        rowCount={links.length}
                        rowHeight={32}
                        rowRenderer={rowRenderer}
                        width={width}
                    />
                )}
            </AutoSizer>
            {contextMenuIndex.index > -1 &&
                <ContextMenu
                    style={{ top: contextMenuIndex.target.getBoundingClientRect().top }}
                    className={'link-contents__context_menu'}
                    menuOptions={getMenuOptions(contextMenuIndex.index)}
                    onClose={action => {
                        if (action) handleAction(action, contextMenuIndex.index);
                        setContextMenuIndex({ index: -1 });
                    }}
                />
            }
        </div >
    );
}

export default LinkContents;